"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { useBridgeTheme } from "../../lib/useBridgeTheme";

const FULLSCREEN_PREF_KEY = "navconsole-fullscreen";
const WATCH_LOG_KEY = "navdash-v12-watch-log";

type Waypoint = {
  id: string;
  name: string;
  lat: number;
  lon: number;
};

type WatchLogRow = {
  id: string;
  timeUtc: string;
  lat: number;
  lon: number;
  cog: number;
  sog: number;
  heading: number;
  activeLeg: string;
  dtg: number;
  xte: number;
  weather: string;
};

const demoRoute: Waypoint[] = [
  { id: "WP01", name: "Apra Harbor Departure", lat: 13.445, lon: 144.640 },
  { id: "WP02", name: "Guam Offshore", lat: 13.300, lon: 145.250 },
  { id: "WP03", name: "Pacific Track", lat: 12.850, lon: 146.800 },
  { id: "WP04", name: "Open Water Leg", lat: 12.250, lon: 148.600 },
  { id: "WP05", name: "Next Ocean WPT", lat: 11.900, lon: 150.100 },
];

const demoOwnShip = {
  lat: 13.205,
  lon: 145.020,
  sog: 11.8,
  cog: 096.4,
  heading: 094.0,
};

function toRad(value: number) {
  return (value * Math.PI) / 180;
}

function toDeg(value: number) {
  return (value * 180) / Math.PI;
}

function normalize360(value: number) {
  return ((value % 360) + 360) % 360;
}

function distanceNm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const earthRadiusNm = 3440.065;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return earthRadiusNm * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function bearingDeg(lat1: number, lon1: number, lat2: number, lon2: number) {
  const phi1 = toRad(lat1);
  const phi2 = toRad(lat2);
  const lambda1 = toRad(lon1);
  const lambda2 = toRad(lon2);
  const y = Math.sin(lambda2 - lambda1) * Math.cos(phi2);
  const x =
    Math.cos(phi1) * Math.sin(phi2) -
    Math.sin(phi1) * Math.cos(phi2) * Math.cos(lambda2 - lambda1);
  return normalize360(toDeg(Math.atan2(y, x)));
}

function crossTrackErrorNm(
  shipLat: number,
  shipLon: number,
  startLat: number,
  startLon: number,
  endLat: number,
  endLon: number,
) {
  const earthRadiusNm = 3440.065;
  const d13 = distanceNm(startLat, startLon, shipLat, shipLon) / earthRadiusNm;
  const theta13 = toRad(bearingDeg(startLat, startLon, shipLat, shipLon));
  const theta12 = toRad(bearingDeg(startLat, startLon, endLat, endLon));
  return Math.asin(Math.sin(d13) * Math.sin(theta13 - theta12)) * earthRadiusNm;
}

function alongTrackNm(
  shipLat: number,
  shipLon: number,
  startLat: number,
  startLon: number,
  endLat: number,
  endLon: number,
) {
  const earthRadiusNm = 3440.065;
  const d13 = distanceNm(startLat, startLon, shipLat, shipLon) / earthRadiusNm;
  const xt = crossTrackErrorNm(shipLat, shipLon, startLat, startLon, endLat, endLon) / earthRadiusNm;
  return Math.acos(Math.cos(d13) / Math.cos(xt)) * earthRadiusNm;
}

function remainingRouteDistanceNm(route: Waypoint[]) {
  if (!route.length) return null;
  const activeIndex = 1;
  const start = route[activeIndex - 1];
  const end = route[activeIndex];
  const legDistance = distanceNm(start.lat, start.lon, end.lat, end.lon);
  const alongTrack = Math.min(Math.max(0, alongTrackNm(demoOwnShip.lat, demoOwnShip.lon, start.lat, start.lon, end.lat, end.lon)), legDistance);
  let total = Math.max(0, legDistance - alongTrack);

  for (let i = activeIndex; i < route.length - 1; i += 1) {
    total += distanceNm(route[i].lat, route[i].lon, route[i + 1].lat, route[i + 1].lon);
  }

  return total;
}

function formatNm(value: number | null | undefined, digits = 2) {
  if (value === null || value === undefined || !Number.isFinite(value)) return "--";
  return value.toFixed(digits);
}

function formatHours(hours: number | null | undefined) {
  if (hours === null || hours === undefined || !Number.isFinite(hours)) return "--";
  const h = Math.floor(hours);
  const m = Math.round((hours - h) * 60);
  return `${h}h ${m.toString().padStart(2, "0")}m`;
}

function csvEscape(value: string | number) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

export default function NavDashV12LabPage() {
  const { nightMode, toggleTheme } = useBridgeTheme();
  const dayMode = !nightMode;
  const mapRef = useRef<any>(null);
  const routeLayerRef = useRef<any>(null);
  const encLayerRef = useRef<any>(null);
  const seamarkLayerRef = useRef<any>(null);

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [activePanel, setActivePanel] = useState("chart");
  const [encLayerOn, setEncLayerOn] = useState(true);
  const [seamarksOn, setSeamarksOn] = useState(true);
  const [corridorNm, setCorridorNm] = useState(2);
  const [watchLog, setWatchLog] = useState<WatchLogRow[]>([]);
  const [offlineCacheArmed, setOfflineCacheArmed] = useState(true);
  const [coastlineMode, setCoastlineMode] = useState("Hybrid geometry + island anchors");

  const activeLegStart = demoRoute[0];
  const activeLegEnd = demoRoute[1];
  const xte = crossTrackErrorNm(
    demoOwnShip.lat,
    demoOwnShip.lon,
    activeLegStart.lat,
    activeLegStart.lon,
    activeLegEnd.lat,
    activeLegEnd.lon,
  );
  const absXte = Math.abs(xte);
  const side = xte > 0 ? "STBD" : "PORT";
  const dtg = remainingRouteDistanceNm(demoRoute);
  const etaHours = dtg ? dtg / Math.max(demoOwnShip.sog, 0.1) : null;
  const legBearing = bearingDeg(activeLegStart.lat, activeLegStart.lon, activeLegEnd.lat, activeLegEnd.lon);
  const destination = demoRoute[demoRoute.length - 1];

  const statusItems = useMemo(() => {
    const xteStatus = absXte > corridorNm ? "RED" : absXte > corridorNm * 0.65 ? "AMBER" : "NORMAL";
    return [
      { label: "AIS Feed", value: "LIVE DEMO", status: "NORMAL" },
      { label: "Route Loaded", value: `${demoRoute.length} WPTS`, status: "NORMAL" },
      { label: "Weather Current", value: "NOAA STAGED", status: "NORMAL" },
      { label: "XTE Monitor", value: `${formatNm(absXte)} NM ${side}`, status: xteStatus },
      { label: "ENC Layer", value: encLayerOn ? "ON" : "OFF", status: encLayerOn ? "NORMAL" : "AMBER" },
      { label: "Offline Cache", value: offlineCacheArmed ? "ARMED" : "OFF", status: offlineCacheArmed ? "NORMAL" : "AMBER" },
    ];
  }, [absXte, corridorNm, encLayerOn, offlineCacheArmed, side]);

  useEffect(() => {
    const updateFullscreenState = () => setIsFullscreen(!!document.fullscreenElement);
    updateFullscreenState();
    document.addEventListener("fullscreenchange", updateFullscreenState);

    try {
      const saved = window.localStorage.getItem(WATCH_LOG_KEY);
      if (saved) setWatchLog(JSON.parse(saved));
    } catch {
      setWatchLog([]);
    }

    return () => document.removeEventListener("fullscreenchange", updateFullscreenState);
  }, []);

  useEffect(() => {
    window.localStorage.setItem(WATCH_LOG_KEY, JSON.stringify(watchLog.slice(0, 36)));
  }, [watchLog]);

  useEffect(() => {
    let cancelled = false;

    async function initMap() {
      if (mapRef.current || cancelled) return;
      const L = await import("leaflet");

      if (!document.querySelector('link[data-navdash-leaflet="true"]')) {
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
        link.setAttribute("data-navdash-leaflet", "true");
        document.head.appendChild(link);
      }

      const map = L.map("v12-map", {
        zoomControl: false,
        attributionControl: false,
        preferCanvas: true,
      }).setView([demoOwnShip.lat, demoOwnShip.lon], 9);

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
      }).addTo(map);

      seamarkLayerRef.current = L.tileLayer("https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png", {
        maxZoom: 18,
      }).addTo(map);

      encLayerRef.current = L.tileLayer.wms(
        "https://gis.charttools.noaa.gov/arcgis/services/MCS/ENCOnline/MapServer/WMSServer",
        {
          layers: "0,1,2,3,4,5,6,7",
          format: "image/png",
          transparent: true,
          opacity: 0.72,
          attribution: "NOAA ENC Display Service",
        } as any,
      ).addTo(map);

      const routeLatLngs = demoRoute.map((wp) => [wp.lat, wp.lon]);
      routeLayerRef.current = L.polyline(routeLatLngs as any, {
        color: "#c9a227",
        weight: 4,
        opacity: 0.95,
      }).addTo(map);

      L.circleMarker([demoOwnShip.lat, demoOwnShip.lon], {
        radius: 9,
        color: "#22d3ee",
        fillColor: "#22d3ee",
        fillOpacity: 0.85,
        weight: 2,
      }).addTo(map);

      demoRoute.forEach((wp) => {
        L.circleMarker([wp.lat, wp.lon], {
          radius: 5,
          color: "#c9a227",
          fillColor: "#c9a227",
          fillOpacity: 0.85,
          weight: 2,
        })
          .bindTooltip(`${wp.id} ${wp.name}`, { permanent: false })
          .addTo(map);
      });

      mapRef.current = map;
      setTimeout(() => map.invalidateSize(), 300);
    }

    initMap();

    return () => {
      cancelled = true;
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !encLayerRef.current) return;

    if (encLayerOn && !map.hasLayer(encLayerRef.current)) {
      encLayerRef.current.addTo(map);
    }

    if (!encLayerOn && map.hasLayer(encLayerRef.current)) {
      map.removeLayer(encLayerRef.current);
    }
  }, [encLayerOn]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !seamarkLayerRef.current) return;

    if (seamarksOn && !map.hasLayer(seamarkLayerRef.current)) {
      seamarkLayerRef.current.addTo(map);
    }

    if (!seamarksOn && map.hasLayer(seamarkLayerRef.current)) {
      map.removeLayer(seamarkLayerRef.current);
    }
  }, [seamarksOn]);

  async function toggleFullscreen() {
    try {
      if (!document.fullscreenElement) {
        window.localStorage.setItem(FULLSCREEN_PREF_KEY, "true");
        await document.documentElement.requestFullscreen?.();
      } else {
        window.localStorage.setItem(FULLSCREEN_PREF_KEY, "false");
        await document.exitFullscreen?.();
      }
    } catch {
      // Browser may block fullscreen unless triggered by a user gesture.
    } finally {
      setTimeout(() => mapRef.current?.invalidateSize(), 400);
    }
  }

  function preserveFullscreenPreference() {
    if (typeof document !== "undefined" && document.fullscreenElement) {
      window.localStorage.setItem(FULLSCREEN_PREF_KEY, "true");
    }
  }

  function addWatchLogEntry() {
    const row: WatchLogRow = {
      id: crypto.randomUUID?.() || String(Date.now()),
      timeUtc: new Date().toISOString().slice(0, 19).replace("T", " ") + " UTC",
      lat: demoOwnShip.lat,
      lon: demoOwnShip.lon,
      cog: demoOwnShip.cog,
      sog: demoOwnShip.sog,
      heading: demoOwnShip.heading,
      activeLeg: `${activeLegStart.id} → ${activeLegEnd.id}`,
      dtg: dtg || 0,
      xte: absXte,
      weather: "NORMAL",
    };

    setWatchLog((rows) => [row, ...rows].slice(0, 36));
  }

  function exportWatchLogCsv() {
    const header = ["Time UTC", "Lat", "Lon", "COG", "SOG", "Heading", "Active Leg", "DTG NM", "XTE NM", "Weather"];
    const rows = watchLog.map((row) => [
      row.timeUtc,
      row.lat.toFixed(5),
      row.lon.toFixed(5),
      row.cog.toFixed(1),
      row.sog.toFixed(1),
      row.heading.toFixed(1),
      row.activeLeg,
      row.dtg.toFixed(2),
      row.xte.toFixed(2),
      row.weather,
    ]);

    const csv = [header, ...rows].map((row) => row.map(csvEscape).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `navdash-watch-log-${new Date().toISOString().slice(0, 10)}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  const pageClass = dayMode
    ? "min-h-screen bg-white text-slate-950"
    : "min-h-screen bg-[#071019] text-slate-100";
  const panelClass = dayMode
    ? "rounded-[2rem] border border-slate-300 bg-white p-5 shadow-xl shadow-slate-900/10"
    : "rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 shadow-2xl shadow-black/40 backdrop-blur-xl";
  const softPanelClass = dayMode
    ? "rounded-3xl border border-slate-300 bg-slate-50 p-4"
    : "rounded-3xl border border-white/10 bg-black/25 p-4";
  const labelClass = dayMode
    ? "text-xs font-black uppercase tracking-[0.22em] text-slate-500"
    : "text-xs font-black uppercase tracking-[0.22em] text-slate-400";
  const mutedClass = dayMode ? "text-slate-600" : "text-slate-400";

  function statusClass(status: string) {
    if (status === "RED") return "border-red-500 bg-red-500 text-black";
    if (status === "AMBER") return "border-amber-500 bg-amber-400 text-black";
    return "border-emerald-500 bg-emerald-400 text-black";
  }

  return (
    <main className={pageClass}>
      <div
        className={
          dayMode
            ? "absolute inset-0 bg-white"
            : "absolute inset-0 bg-[radial-gradient(circle_at_12%_0%,rgba(201,162,39,.28),transparent_30%),radial-gradient(circle_at_90%_10%,rgba(56,189,248,.12),transparent_28%),linear-gradient(135deg,#071019,#101c2b_48%,#071019)]"
        }
      />

      <style jsx global>{`
        .navdash-v12-day .leaflet-container {
          background: #e2e8f0;
        }
        .navdash-v12-night .leaflet-container {
          background: #071019;
          filter: saturate(0.88) brightness(0.82);
        }
      `}</style>

      <div className={`relative z-10 min-h-screen p-5 2xl:p-7 ${dayMode ? "navdash-v12-day" : "navdash-v12-night"}`}>
        <header className="mb-5 rounded-[2rem] border border-white/10 bg-white/[0.055] p-5 backdrop-blur-xl shadow-2xl shadow-black/35">
          <div className="flex flex-col gap-5 xl:flex-row xl:items-center xl:justify-between">
            <div className="flex items-center gap-4">
              <div className="grid h-16 w-16 place-items-center rounded-3xl border border-wardGold/45 bg-wardGold/15 text-3xl font-black text-wardGold">
                N
              </div>
              <div>
                <div className="text-xs font-bold uppercase tracking-[0.42em] text-wardGold">M/V MB480</div>
                <h1 className={dayMode ? "text-4xl font-black tracking-tight text-slate-950 2xl:text-5xl" : "text-4xl font-black tracking-tight text-white 2xl:text-5xl"}>
                  NavDash v1.2 Lab
                </h1>
                <div className={dayMode ? "mt-1 text-sm text-slate-700" : "mt-1 text-sm text-slate-300"}>
                  Chart awareness + watch log + route monitoring prototype
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-end gap-3">
              <Link
                href="/"
                onClick={preserveFullscreenPreference}
                className="inline-flex h-12 w-[156px] flex-none items-center justify-center whitespace-nowrap rounded-2xl border border-white/10 bg-white/10 px-4 text-sm font-black text-slate-100 hover:bg-white/15"
              >
                NavDash
              </Link>
              <button onClick={toggleFullscreen} className="inline-flex h-12 w-[156px] flex-none items-center justify-center whitespace-nowrap rounded-2xl border border-white/10 bg-white/10 px-4 text-sm font-black text-slate-100 hover:bg-white/15">
                {isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
              </button>
              <button onClick={toggleTheme} className="inline-flex h-12 w-[156px] flex-none items-center justify-center whitespace-nowrap rounded-2xl border border-white/10 bg-white/10 px-4 text-sm font-black text-slate-100 hover:bg-white/15">
                {dayMode ? "Bridge Night" : "Day Mode"}
              </button>
            </div>
          </div>
        </header>

        <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-7">
          {[
            ["chart", "Chart Awareness"],
            ["route", "Route Monitor"],
            ["watch", "Watch Log"],
            ["status", "Status Board"],
            ["offline", "Offline Mode"],
            ["coast", "Coastline Pro"],
            ["build", "Build Info"],
          ].map(([key, label]) => (
            <button
              key={key}
              onClick={() => setActivePanel(key)}
              className={
                activePanel === key
                  ? "rounded-2xl border border-wardGold/50 bg-wardGold px-3 py-3 text-sm font-black text-[#111827]"
                  : dayMode
                    ? "rounded-2xl border border-slate-300 bg-white px-3 py-3 text-sm font-black text-slate-800 hover:bg-slate-50"
                    : "rounded-2xl border border-white/10 bg-white/10 px-3 py-3 text-sm font-black text-slate-100 hover:bg-white/15"
              }
            >
              {label}
            </button>
          ))}
        </div>

        <div className="grid gap-5 xl:grid-cols-[1.55fr_.85fr]">
          <section className={panelClass}>
            <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <div className={labelClass}>ENC Awareness Layer</div>
                <h2 className={dayMode ? "mt-1 text-3xl font-black text-slate-950" : "mt-1 text-3xl font-black text-white"}>
                  Chart-style prototype display
                </h2>
                <p className={`mt-1 text-sm ${mutedClass}`}>
                  Awareness-only basemap with OSM, seamarks, and a staged NOAA ENC WMS layer where NOAA coverage exists.
                </p>
              </div>
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => setEncLayerOn((v) => !v)}
                  className={encLayerOn ? "rounded-2xl border border-emerald-600 bg-emerald-400 px-4 py-3 text-sm font-black text-black" : "rounded-2xl border border-slate-400 bg-slate-200 px-4 py-3 text-sm font-black text-slate-900"}
                >
                  ENC Layer {encLayerOn ? "ON" : "OFF"}
                </button>
                <button
                  onClick={() => setSeamarksOn((v) => !v)}
                  className={seamarksOn ? "rounded-2xl border border-cyan-600 bg-cyan-300 px-4 py-3 text-sm font-black text-black" : "rounded-2xl border border-slate-400 bg-slate-200 px-4 py-3 text-sm font-black text-slate-900"}
                >
                  Seamarks {seamarksOn ? "ON" : "OFF"}
                </button>
              </div>
            </div>

            <div id="v12-map" className="h-[560px] overflow-hidden rounded-[1.6rem] border border-white/10 bg-black/30" />

            <div className={dayMode ? "mt-4 rounded-3xl border border-amber-300 bg-amber-50 p-4 text-sm leading-6 text-amber-950" : "mt-4 rounded-3xl border border-amber-300/30 bg-amber-400/10 p-4 text-sm leading-6 text-amber-100"}>
              <span className="font-black">Prototype note:</span> This is not an ECDIS, not approved for navigation, and not a chart carriage product. It is a visual test bed for deciding whether an ENC awareness layer belongs in v1.2.
            </div>
          </section>

          <aside className="grid gap-5">
            <section className={panelClass}>
              <div className={labelClass}>Voyage Snapshot</div>
              <div className="mt-4 grid gap-3">
                <div className={softPanelClass}>
                  <div className={labelClass}>Destination</div>
                  <div className="mt-2 text-2xl font-black text-wardGold">{destination.name}</div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className={softPanelClass}>
                    <div className={labelClass}>DTG</div>
                    <div className="mt-2 text-2xl font-black text-wardGold">{formatNm(dtg)}</div>
                    <div className={`text-xs ${mutedClass}`}>NM</div>
                  </div>
                  <div className={softPanelClass}>
                    <div className={labelClass}>ETA</div>
                    <div className={dayMode ? "mt-2 text-2xl font-black text-slate-950" : "mt-2 text-2xl font-black text-white"}>{formatHours(etaHours)}</div>
                  </div>
                  <div className={softPanelClass}>
                    <div className={labelClass}>XTE</div>
                    <div className={absXte > corridorNm ? "mt-2 text-2xl font-black text-red-500" : "mt-2 text-2xl font-black text-emerald-400"}>
                      {formatNm(absXte)} {side}
                    </div>
                  </div>
                  <div className={softPanelClass}>
                    <div className={labelClass}>Leg BRG</div>
                    <div className={dayMode ? "mt-2 text-2xl font-black text-slate-950" : "mt-2 text-2xl font-black text-white"}>{legBearing.toFixed(1)}°T</div>
                  </div>
                </div>
              </div>
            </section>

            <section className={panelClass}>
              <div className={labelClass}>Route Corridor</div>
              <div className="mt-3 flex items-center justify-between gap-4">
                <input
                  type="range"
                  min="0.5"
                  max="5"
                  step="0.5"
                  value={corridorNm}
                  onChange={(e) => setCorridorNm(Number(e.target.value))}
                  className="w-full"
                />
                <div className="w-20 rounded-2xl border border-wardGold/40 bg-wardGold px-3 py-2 text-center text-sm font-black text-black">
                  {corridorNm.toFixed(1)} NM
                </div>
              </div>
              <p className={`mt-3 text-sm leading-6 ${mutedClass}`}>
                Prototype corridor check compares current demo XTE to the selected corridor width. Later this can read the live route and own-ship feed.
              </p>
            </section>
          </aside>
        </div>

        <section className="mt-5 grid gap-5 xl:grid-cols-2">
          <div className={panelClass}>
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className={labelClass}>Watch Log Prototype</div>
                <h3 className={dayMode ? "mt-1 text-2xl font-black text-slate-950" : "mt-1 text-2xl font-black text-white"}>Auto / manual position log</h3>
              </div>
              <div className="flex gap-3">
                <button onClick={addWatchLogEntry} className="rounded-2xl border border-wardGold/40 bg-wardGold px-4 py-3 text-sm font-black text-black">Add Test Entry</button>
                <button onClick={exportWatchLogCsv} className={dayMode ? "rounded-2xl border border-slate-300 bg-slate-100 px-4 py-3 text-sm font-black text-slate-900" : "rounded-2xl border border-white/10 bg-white/10 px-4 py-3 text-sm font-black text-slate-100"}>Export CSV</button>
              </div>
            </div>

            <div className="mt-4 max-h-72 overflow-auto rounded-3xl border border-white/10">
              <table className="w-full text-left text-xs">
                <thead className={dayMode ? "bg-slate-100 text-slate-600" : "bg-black/35 text-slate-300"}>
                  <tr>
                    <th className="p-3">Time</th>
                    <th className="p-3">Position</th>
                    <th className="p-3">SOG/COG</th>
                    <th className="p-3">Leg</th>
                    <th className="p-3">DTG</th>
                    <th className="p-3">XTE</th>
                  </tr>
                </thead>
                <tbody>
                  {watchLog.length === 0 ? (
                    <tr><td colSpan={6} className={`p-4 text-center ${mutedClass}`}>No test entries yet.</td></tr>
                  ) : (
                    watchLog.map((row) => (
                      <tr key={row.id} className={dayMode ? "border-t border-slate-200" : "border-t border-white/10"}>
                        <td className="p-3">{row.timeUtc}</td>
                        <td className="p-3">{row.lat.toFixed(5)}, {row.lon.toFixed(5)}</td>
                        <td className="p-3">{row.sog.toFixed(1)} kt / {row.cog.toFixed(1)}°</td>
                        <td className="p-3">{row.activeLeg}</td>
                        <td className="p-3">{row.dtg.toFixed(2)} NM</td>
                        <td className="p-3">{row.xte.toFixed(2)} NM</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className={panelClass}>
            <div className={labelClass}>Status Board</div>
            <h3 className={dayMode ? "mt-1 text-2xl font-black text-slate-950" : "mt-1 text-2xl font-black text-white"}>Bridge goblin checklist</h3>
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              {statusItems.map((item) => (
                <div key={item.label} className={softPanelClass}>
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className={labelClass}>{item.label}</div>
                      <div className="mt-1 text-xl font-black">{item.value}</div>
                    </div>
                    <div className={`rounded-2xl border px-3 py-2 text-xs font-black ${statusClass(item.status)}`}>
                      {item.status}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mt-5 grid gap-5 xl:grid-cols-3">
          <div className={panelClass}>
            <div className={labelClass}>Offline Mode</div>
            <h3 className="mt-1 text-2xl font-black">Cache readiness</h3>
            <button
              onClick={() => setOfflineCacheArmed((v) => !v)}
              className={offlineCacheArmed ? "mt-4 rounded-2xl border border-emerald-700 bg-emerald-400 px-4 py-3 text-sm font-black text-black" : "mt-4 rounded-2xl border border-amber-700 bg-amber-400 px-4 py-3 text-sm font-black text-black"}
            >
              Offline Cache {offlineCacheArmed ? "Armed" : "Off"}
            </button>
            <p className={`mt-4 text-sm leading-6 ${mutedClass}`}>
              Future build target: cache last route, last weather, last coastline/chart package, and last 36 hours of watch log for Starlink/LAN hiccups.
            </p>
          </div>

          <div className={panelClass}>
            <div className={labelClass}>Coastline Pro</div>
            <h3 className="mt-1 text-2xl font-black">Distance-to-land engine</h3>
            <select
              value={coastlineMode}
              onChange={(e) => setCoastlineMode(e.target.value)}
              className={dayMode ? "mt-4 w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm font-bold text-slate-950" : "mt-4 w-full rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm font-bold text-white"}
            >
              <option>Hybrid geometry + island anchors</option>
              <option>True coastline geometry only</option>
              <option>Reference anchors only</option>
            </select>
            <p className={`mt-4 text-sm leading-6 ${mutedClass}`}>
              Prototype mode selector for the ECR distance-from-land card. v1.2 can promote this into the actual ECR display once the dataset is trustworthy.
            </p>
          </div>

          <div className={panelClass}>
            <div className={labelClass}>Build Info</div>
            <h3 className="mt-1 text-2xl font-black">NavDash v1.2 Lab</h3>
            <div className={`mt-4 grid gap-2 text-sm ${mutedClass}`}>
              <div>Build Type: Local prototype page</div>
              <div>Route: /v12-test</div>
              <div>Chart Layer: NOAA ENC WMS staged</div>
              <div>Map: Leaflet + OSM + OpenSeaMap</div>
              <div>Storage: localStorage watch log demo</div>
              <div>Navigation Use: Not approved</div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
